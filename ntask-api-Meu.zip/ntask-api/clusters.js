import cluster from "cluster";
import os from "os";

const CPUS = os.cpus();
if (cluster.isMaster) {
    CPUS.forEach(() => cluster.fork());
    cluster.on("escutando", worker => {
        console.log("Cluster %d conectado", worker.process.pid);
    });
    cluster.on("desconectado", worker => {
        console.log("Cluster %d desconectado", worker.process.pid);
    });
    cluster.on("fora do ar", worker => {
        console.log("Cluster %d saiu do ar", worker.process.pid);
        cluster.fork();
        // imicia novo cluster quandp um cluster sai do ar
    });
} else {
    require("./indes.js");
}