define({ "api": [
  {
    "type": "get",
    "url": "/API",
    "title": "Status",
    "group": "Status",
    "version": "0.0.0",
    "filename": "routes/index.js",
    "groupTitle": "Status",
    "name": "GetApi"
  }
] });
