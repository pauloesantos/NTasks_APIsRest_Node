define({
  "name": "Documentação - Node Task API",
  "version": "1.0.0",
  "description": "API gestão de tarefas",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2020-11-30T12:50:54.029Z",
    "url": "https://apidocjs.com",
    "version": "0.25.0"
  }
});
