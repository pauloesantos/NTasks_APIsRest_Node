module.exports = app => {
    /**
     * @api {get} /API Status
     * @apiGroup Status
     * @apiSucess {String} status mensagem de status da API
     * @apiSucessExample {json} Sucesso
     *      HTTP/1.1 200 ok
     *      {"status": ""}
     */
    app.get("/", (req, res) => {
        res.json({ status: "NTask API" });
    });
};